import { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import ContactList from './components/ContactList';
import ContactDetail from './components/ContactDetail';
import ContactForm from './components/ContactForm';
import Toast from './components/Toast';

const API = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

export default function App() {
  const [contacts, setContacts] = useState([]);
  const [selected, setSelected] = useState(null);
  const [search, setSearch] = useState('');
  const [activeTag, setActiveTag] = useState('All');
  const [showStarred, setShowStarred] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editContact, setEditContact] = useState(null);
  const [toast, setToast] = useState(null);
  const [loading, setLoading] = useState(false);

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const fetchContacts = useCallback(async () => {
    setLoading(true);
    try {
      const params = {};
      if (search) params.search = search;
      if (activeTag !== 'All') params.tag = activeTag;
      if (showStarred) params.starred = true;
      const res = await axios.get(`${API}/contacts`, { params });
      setContacts(res.data);
      const currentSelectedId = selected?._id;
      const stillExists = currentSelectedId && res.data.find(c => c._id === currentSelectedId);
      if (stillExists) {
        setSelected(stillExists);
      } else {
        setSelected(res.data[0] || null);
      }
    } catch (err) {
      console.error('Fetch error:', err);
      showToast(`Failed to load contacts: ${err.message || err.response?.status || 'Unknown error'}`, 'error');
    } finally {
      setLoading(false);
    }
  }, [search, activeTag, showStarred]);

  useEffect(() => {
    const delay = setTimeout(fetchContacts, 300);
    return () => clearTimeout(delay);
  }, [fetchContacts]);

  const handleCreate = async (data) => {
    try {
      const res = await axios.post(`${API}/contacts`, data);
      showToast('Contact added');
      setShowForm(false);
      setEditContact(null);
      await fetchContacts();
      setSelected(res.data);
    } catch (err) {
      console.error('Create error:', err);
      showToast(err.response?.data?.message || err.message || 'Failed to add contact', 'error');
    }
  };

  const handleUpdate = async (data) => {
    try {
      const res = await axios.put(`${API}/contacts/${editContact._id}`, data);
      showToast('Contact updated');
      setShowForm(false);
      setEditContact(null);
      await fetchContacts();
      setSelected(res.data);
    } catch (err) {
      console.error('Update error:', err);
      showToast(err.response?.data?.message || err.message || 'Failed to update contact', 'error');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this contact?')) return;
    try {
      await axios.delete(`${API}/contacts/${id}`);
      showToast('Contact deleted');
      setSelected(null);
      await fetchContacts();
    } catch (err) {
      console.error('Delete error:', err);
      showToast(err.message || 'Failed to delete contact', 'error');
    }
  };

  const handleStar = async (id) => {
    try {
      const res = await axios.patch(`${API}/contacts/${id}/star`);
      setContacts(prev => prev.map(c => c._id === id ? res.data : c));
      if (selected?._id === id) setSelected(res.data);
    } catch (err) {
      console.error('Star error:', err);
      showToast(err.message || 'Failed to update star', 'error');
    }
  };

  const openEdit = (contact) => {
    setEditContact(contact);
    setShowForm(true);
  };

  const tags = ['All', 'Work', 'Client', 'Family', 'Friend', 'Other'];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>

      {/* Top Bar */}
      <header style={{
        background: 'var(--bg-white)',
        borderBottom: '1px solid var(--border)',
        padding: '0 20px',
        height: '56px',
        display: 'flex',
        alignItems: 'center',
        gap: '14px',
        flexShrink: 0,
      }}>
        <span style={{ fontSize: '17px', fontWeight: '600', color: 'var(--accent)', letterSpacing: '-0.02em', marginRight: '6px' }}>
          Vault
        </span>

        <div style={{
          flex: 1,
          maxWidth: '360px',
          height: '34px',
          border: '1px solid var(--border)',
          borderRadius: 'var(--radius-sm)',
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          padding: '0 10px',
          background: 'var(--bg-page)',
        }}>
          <svg width="13" height="13" viewBox="0 0 16 16" fill="none">
            <circle cx="7" cy="7" r="5.5" stroke="var(--text-muted)" strokeWidth="1.5"/>
            <path d="M11 11l3 3" stroke="var(--text-muted)" strokeWidth="1.5" strokeLinecap="round"/>
          </svg>
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search by name, email, company..."
            style={{
              border: 'none',
              outline: 'none',
              background: 'transparent',
              flex: 1,
              color: 'var(--text-primary)',
              fontSize: '13px',
            }}
          />
          {search && (
            <button onClick={() => setSearch('')} style={{ border: 'none', background: 'none', color: 'var(--text-muted)', fontSize: '16px', lineHeight: 1, padding: 0 }}>×</button>
          )}
        </div>

        <div style={{ display: 'flex', gap: '8px', marginLeft: 'auto', alignItems: 'center' }}>
          <button
            onClick={() => setShowStarred(!showStarred)}
            style={{
              height: '34px',
              padding: '0 14px',
              borderRadius: 'var(--radius-sm)',
              border: '1px solid var(--border)',
              background: showStarred ? 'var(--accent-light)' : 'var(--bg-white)',
              color: showStarred ? 'var(--accent)' : 'var(--text-secondary)',
              fontWeight: showStarred ? '500' : '400',
              display: 'flex',
              alignItems: 'center',
              gap: '5px',
            }}
          >
            <span style={{ color: 'var(--star)' }}>★</span> Starred
          </button>
          <button
            onClick={() => { setEditContact(null); setShowForm(true); }}
            style={{
              height: '34px',
              padding: '0 16px',
              borderRadius: 'var(--radius-sm)',
              border: 'none',
              background: 'var(--accent)',
              color: '#fff',
              fontWeight: '500',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
            }}
          >
            + New contact
          </button>
        </div>
      </header>

      {/* Tag Filter Bar */}
      <div style={{
        background: 'var(--bg-white)',
        borderBottom: '1px solid var(--border)',
        padding: '0 20px',
        height: '42px',
        display: 'flex',
        alignItems: 'center',
        gap: '6px',
        flexShrink: 0,
      }}>
        {tags.map(tag => (
          <button
            key={tag}
            onClick={() => setActiveTag(tag)}
            style={{
              height: '26px',
              padding: '0 12px',
              borderRadius: '20px',
              border: '1px solid',
              borderColor: activeTag === tag ? 'var(--accent)' : 'var(--border)',
              background: activeTag === tag ? 'var(--accent)' : 'transparent',
              color: activeTag === tag ? '#fff' : 'var(--text-secondary)',
              fontWeight: activeTag === tag ? '500' : '400',
              fontSize: '12px',
            }}
          >
            {tag}
          </button>
        ))}
        <span style={{ marginLeft: 'auto', fontSize: '12px', color: 'var(--text-muted)' }}>
          {contacts.length} contact{contacts.length !== 1 ? 's' : ''}
        </span>
      </div>

      {/* Main Body */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        <ContactList
          contacts={contacts}
          selected={selected}
          onSelect={setSelected}
          loading={loading}
        />
        <ContactDetail
          contact={selected}
          onEdit={openEdit}
          onDelete={handleDelete}
          onStar={handleStar}
        />
      </div>

      {/* Form Modal */}
      {showForm && (
        <ContactForm
          contact={editContact}
          onSubmit={editContact ? handleUpdate : handleCreate}
          onClose={() => { setShowForm(false); setEditContact(null); }}
        />
      )}

      {/* Toast */}
      {toast && <Toast message={toast.message} type={toast.type} />}
    </div>
  );
}